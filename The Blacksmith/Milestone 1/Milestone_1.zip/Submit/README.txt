README.txt

The purpose of this game is to walk around and enjoy your workshop while you try to find that longsword you misplaced. You only have 60 seconds however to do this.
Good Luck.



During this assignment I learned how to create a first person character controller, that was the first thing that I really struggled with. I used planes to create the environment the player walks around in, which worked out quite nicely. I first wanted to use a bunch of cubes to do this, but it was hard to navigate the scene view this way so I changed them.